(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/lib/types.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// TypeScript Types & Interfaces for Task & Resource Management System
// ==================== ENUMS ====================
__turbopack_context__.s([
    "CAR_STATUS_LABELS",
    ()=>CAR_STATUS_LABELS,
    "CarStatus",
    ()=>CarStatus,
    "CarStatusLabels",
    ()=>CarStatusLabels,
    "DefaultRolePermissions",
    ()=>DefaultRolePermissions,
    "DefaultRoleScope",
    ()=>DefaultRoleScope,
    "HalfDayPeriod",
    ()=>HalfDayPeriod,
    "HalfDayPeriodLabels",
    ()=>HalfDayPeriodLabels,
    "LEAVE_STATUS_LABELS",
    ()=>LEAVE_STATUS_LABELS,
    "LEAVE_TYPE_CONFIGS",
    ()=>LEAVE_TYPE_CONFIGS,
    "LEAVE_TYPE_LABELS",
    ()=>LEAVE_TYPE_LABELS,
    "LeaveApprovalChain",
    ()=>LeaveApprovalChain,
    "LeaveDurationType",
    ()=>LeaveDurationType,
    "LeaveDurationTypeLabels",
    ()=>LeaveDurationTypeLabels,
    "LeaveStatus",
    ()=>LeaveStatus,
    "LeaveStatusLabels",
    ()=>LeaveStatusLabels,
    "LeaveType",
    ()=>LeaveType,
    "LeaveTypeLabels",
    ()=>LeaveTypeLabels,
    "ROLE_LABELS",
    ()=>ROLE_LABELS,
    "Role",
    ()=>Role,
    "RoleHierarchy",
    ()=>RoleHierarchy,
    "RoleLabels",
    ()=>RoleLabels,
    "STATUS_LABELS",
    ()=>STATUS_LABELS,
    "SUB_UNIT_LABELS",
    ()=>SUB_UNIT_LABELS,
    "SubUnitType",
    ()=>SubUnitType,
    "SubUnitTypeLabels",
    ()=>SubUnitTypeLabels,
    "TaskStatus",
    ()=>TaskStatus,
    "TaskStatusColors",
    ()=>TaskStatusColors,
    "TaskStatusLabels",
    ()=>TaskStatusLabels
]);
var Role = /*#__PURE__*/ function(Role) {
    Role["ADMIN"] = "ADMIN";
    Role["CUSTOMER_SERVICE"] = "CUSTOMER_SERVICE";
    Role["FINANCE_LEADER"] = "FINANCE_LEADER";
    Role["FINANCE"] = "FINANCE";
    Role["SALES_LEADER"] = "SALES_LEADER";
    Role["SALES"] = "SALES";
    Role["HEAD_TECH"] = "HEAD_TECH";
    Role["LEADER"] = "LEADER";
    Role["TECH"] = "TECH";
    return Role;
}({});
var TaskStatus = /*#__PURE__*/ function(TaskStatus) {
    TaskStatus["WAITING"] = "WAITING";
    TaskStatus["IN_PROGRESS"] = "IN_PROGRESS";
    TaskStatus["DONE"] = "DONE";
    TaskStatus["CANCELLED"] = "CANCELLED";
    return TaskStatus;
}({});
var LeaveStatus = /*#__PURE__*/ function(LeaveStatus) {
    LeaveStatus["PENDING"] = "PENDING";
    LeaveStatus["APPROVED"] = "APPROVED";
    LeaveStatus["REJECTED"] = "REJECTED";
    LeaveStatus["CANCELLED"] = "CANCELLED";
    return LeaveStatus;
}({});
var LeaveType = /*#__PURE__*/ function(LeaveType) {
    LeaveType["SICK"] = "SICK";
    LeaveType["PERSONAL"] = "PERSONAL";
    LeaveType["VACATION"] = "VACATION";
    LeaveType["BIRTHDAY"] = "BIRTHDAY";
    LeaveType["OTHER"] = "OTHER";
    return LeaveType;
}({});
var LeaveDurationType = /*#__PURE__*/ function(LeaveDurationType) {
    LeaveDurationType["FULL_DAY"] = "FULL_DAY";
    LeaveDurationType["HALF_DAY"] = "HALF_DAY";
    LeaveDurationType["TIME_BASED"] = "TIME_BASED";
    return LeaveDurationType;
}({});
var HalfDayPeriod = /*#__PURE__*/ function(HalfDayPeriod) {
    HalfDayPeriod["MORNING"] = "MORNING";
    HalfDayPeriod["AFTERNOON"] = "AFTERNOON";
    return HalfDayPeriod;
}({});
const LEAVE_TYPE_CONFIGS = {
    ["SICK"]: {
        type: "SICK",
        label: 'ลาป่วย',
        quotaPerYear: 30,
        allowedDurationTypes: [
            "FULL_DAY",
            "HALF_DAY"
        ],
        requiresDocumentation: false,
        maxConsecutiveDays: 30
    },
    ["PERSONAL"]: {
        type: "PERSONAL",
        label: 'ลากิจ',
        quotaPerYear: 3,
        allowedDurationTypes: [
            "FULL_DAY"
        ],
        minDaysNotice: 1,
        maxConsecutiveDays: 3
    },
    ["VACATION"]: {
        type: "VACATION",
        label: 'ลาพักร้อน',
        quotaPerYear: 6,
        allowedDurationTypes: [
            "FULL_DAY",
            "TIME_BASED"
        ],
        calculatedByMonthsEmployed: true,
        minDaysNotice: 3,
        maxConsecutiveDays: 6
    },
    ["BIRTHDAY"]: {
        type: "BIRTHDAY",
        label: 'ลาเดือนเกิด',
        quotaPerYear: 1,
        allowedDurationTypes: [
            "FULL_DAY"
        ],
        isBirthdayMonth: true,
        maxConsecutiveDays: 1
    },
    ["OTHER"]: {
        type: "OTHER",
        label: 'อื่นๆ',
        quotaPerYear: 0,
        allowedDurationTypes: [
            "FULL_DAY",
            "HALF_DAY",
            "TIME_BASED"
        ],
        requiresDocumentation: true
    }
};
var SubUnitType = /*#__PURE__*/ function(SubUnitType) {
    SubUnitType["RENTAL"] = "RENTAL";
    SubUnitType["INSTALLATION"] = "INSTALLATION";
    SubUnitType["PRINTER"] = "PRINTER";
    SubUnitType["IT"] = "IT";
    return SubUnitType;
}({});
var CarStatus = /*#__PURE__*/ function(CarStatus) {
    CarStatus["AVAILABLE"] = "AVAILABLE";
    CarStatus["IN_USE"] = "IN_USE";
    CarStatus["MAINTENANCE"] = "MAINTENANCE";
    CarStatus["OUT_OF_SERVICE"] = "OUT_OF_SERVICE";
    return CarStatus;
}({});
const RoleHierarchy = {
    ["ADMIN"]: 100,
    ["CUSTOMER_SERVICE"]: 50,
    ["FINANCE_LEADER"]: 60,
    ["FINANCE"]: 40,
    ["SALES_LEADER"]: 60,
    ["SALES"]: 40,
    ["HEAD_TECH"]: 70,
    ["LEADER"]: 50,
    ["TECH"]: 30
};
const LeaveApprovalChain = {
    ["TECH"]: [
        "LEADER",
        "HEAD_TECH"
    ],
    ["LEADER"]: [
        "HEAD_TECH"
    ],
    ["HEAD_TECH"]: [
        "ADMIN"
    ],
    ["SALES"]: [
        "SALES_LEADER"
    ],
    ["SALES_LEADER"]: [
        "ADMIN"
    ],
    ["FINANCE"]: [
        "FINANCE_LEADER"
    ],
    ["FINANCE_LEADER"]: [
        "ADMIN"
    ],
    ["CUSTOMER_SERVICE"]: [
        "ADMIN"
    ],
    ["ADMIN"]: []
};
const DefaultRolePermissions = {
    ["ADMIN"]: {
        canViewTasks: true,
        canCreateTasks: true,
        canEditTaskDetails: true,
        canDeleteTasks: true,
        canAssignTasks: true,
        canManageTasks: true,
        canViewAllCalendars: true,
        canViewTeamCalendar: true,
        canBookVehicles: true,
        canManageFleet: true,
        canManageCars: true,
        canApproveLeave: true,
        canViewLeaveRequests: true,
        canManageUsers: true,
        canViewAllUsers: true,
        canManageDepartments: true,
        canManageDailyTechnician: true,
        canViewReports: true,
        canExportData: true,
        canRunScheduler: true
    },
    ["CUSTOMER_SERVICE"]: {
        canViewTasks: true,
        canCreateTasks: true,
        canEditTaskDetails: true,
        canViewAllCalendars: true,
        canViewTeamCalendar: true,
        canBookVehicles: true,
        canViewLeaveRequests: true,
        canViewAllUsers: true,
        canViewReports: true
    },
    ["FINANCE_LEADER"]: {
        canViewTasks: true,
        canViewAllCalendars: true,
        canViewTeamCalendar: true,
        canApproveLeave: true,
        canViewLeaveRequests: true,
        canManageUsers: true,
        canViewAllUsers: true,
        canViewReports: true,
        canExportData: true
    },
    ["FINANCE"]: {
        canViewTasks: true,
        canViewTeamCalendar: true,
        canViewLeaveRequests: true,
        canViewReports: true
    },
    ["SALES_LEADER"]: {
        canViewTasks: true,
        canCreateTasks: true,
        canViewAllCalendars: true,
        canViewTeamCalendar: true,
        canApproveLeave: true,
        canViewLeaveRequests: true,
        canManageUsers: true,
        canViewAllUsers: true,
        canViewReports: true
    },
    ["SALES"]: {
        canViewTasks: true,
        canCreateTasks: true,
        canViewTeamCalendar: true,
        canViewLeaveRequests: true,
        canViewReports: true
    },
    ["HEAD_TECH"]: {
        canViewTasks: true,
        canCreateTasks: true,
        canEditTaskDetails: true,
        canDeleteTasks: true,
        canAssignTasks: true,
        canManageTasks: true,
        canViewAllCalendars: true,
        canViewTeamCalendar: true,
        canBookVehicles: true,
        canManageFleet: true,
        canManageCars: true,
        canApproveLeave: true,
        canViewLeaveRequests: true,
        canManageUsers: true,
        canViewAllUsers: true,
        canManageDepartments: true,
        canManageDailyTechnician: true,
        canViewReports: true,
        canExportData: true,
        canRunScheduler: true
    },
    ["LEADER"]: {
        canViewTasks: true,
        canCreateTasks: true,
        canEditTaskDetails: true,
        canAssignTasks: true,
        canViewTeamCalendar: true,
        canBookVehicles: true,
        canApproveLeave: true,
        canViewLeaveRequests: true,
        canManageDailyTechnician: true,
        canViewReports: true
    },
    ["TECH"]: {
        canViewTasks: true,
        canViewTeamCalendar: true,
        canBookVehicles: true,
        canViewLeaveRequests: true
    }
};
const DefaultRoleScope = {
    ["ADMIN"]: {
        type: 'ALL'
    },
    ["CUSTOMER_SERVICE"]: {
        type: 'ALL'
    },
    ["FINANCE_LEADER"]: {
        type: 'DEPARTMENT'
    },
    ["FINANCE"]: {
        type: 'SELF'
    },
    ["SALES_LEADER"]: {
        type: 'DEPARTMENT'
    },
    ["SALES"]: {
        type: 'SELF'
    },
    ["HEAD_TECH"]: {
        type: 'DEPARTMENT'
    },
    ["LEADER"]: {
        type: 'SUBUNIT'
    },
    ["TECH"]: {
        type: 'SELF'
    }
};
const TaskStatusColors = {
    ["WAITING"]: '#9CA3AF',
    ["IN_PROGRESS"]: '#3B82F6',
    ["DONE"]: '#22C55E',
    ["CANCELLED"]: '#EF4444'
};
const TaskStatusLabels = {
    ["WAITING"]: 'รอรับงาน',
    ["IN_PROGRESS"]: 'กำลังทำ',
    ["DONE"]: 'จบงาน',
    ["CANCELLED"]: 'ยกเลิก'
};
const LeaveTypeLabels = {
    ["SICK"]: 'ลาป่วย',
    ["PERSONAL"]: 'ลากิจ',
    ["VACATION"]: 'ลาพักร้อน',
    ["BIRTHDAY"]: 'ลาเดือนเกิด',
    ["OTHER"]: 'อื่นๆ'
};
const LeaveDurationTypeLabels = {
    ["FULL_DAY"]: 'เต็มวัน',
    ["HALF_DAY"]: 'ครึ่งวัน',
    ["TIME_BASED"]: 'ตามเวลา'
};
const HalfDayPeriodLabels = {
    ["MORNING"]: 'ช่วงเช้า (08:00-12:00)',
    ["AFTERNOON"]: 'ช่วงบ่าย (13:00-17:00)'
};
const LeaveStatusLabels = {
    ["PENDING"]: 'รออนุมัติ',
    ["APPROVED"]: 'อนุมัติ',
    ["REJECTED"]: 'ไม่อนุมัติ',
    ["CANCELLED"]: 'ยกเลิก'
};
const RoleLabels = {
    ["ADMIN"]: 'ผู้บริหารสูงสุด',
    ["CUSTOMER_SERVICE"]: 'ฝ่ายบริการลูกค้า',
    ["FINANCE_LEADER"]: 'หัวหน้าฝ่ายการเงิน',
    ["FINANCE"]: 'เจ้าหน้าที่การเงิน',
    ["SALES_LEADER"]: 'หัวหน้าฝ่ายขาย',
    ["SALES"]: 'พนักงานขาย',
    ["HEAD_TECH"]: 'หัวหน้าแผนกช่าง',
    ["LEADER"]: 'หัวหน้าทีม',
    ["TECH"]: 'ช่าง'
};
const SubUnitTypeLabels = {
    ["RENTAL"]: 'ทีมเครื่องเช่า',
    ["INSTALLATION"]: 'ทีมติดตั้ง',
    ["PRINTER"]: 'ทีมปริ้นเตอร์',
    ["IT"]: 'ทีมไอที'
};
const STATUS_LABELS = TaskStatusLabels;
const LEAVE_STATUS_LABELS = LeaveStatusLabels;
const LEAVE_TYPE_LABELS = LeaveTypeLabels;
const ROLE_LABELS = RoleLabels;
const SUB_UNIT_LABELS = SubUnitTypeLabels;
const CAR_STATUS_LABELS = {
    ["AVAILABLE"]: 'ว่าง',
    ["IN_USE"]: 'ใช้งานอยู่',
    ["MAINTENANCE"]: 'ซ่อมบำรุง',
    ["OUT_OF_SERVICE"]: 'ไม่พร้อมใช้งาน'
};
const CarStatusLabels = CAR_STATUS_LABELS;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/env.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "envSchema",
    ()=>envSchema,
    "getEnv",
    ()=>getEnv,
    "validateEnv",
    ()=>validateEnv
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__ = __turbopack_context__.i("[project]/node_modules/zod/v4/classic/external.js [app-client] (ecmascript) <export * as z>");
;
const envSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    JWT_SECRET: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().min(10, 'JWT_SECRET must be at least 10 characters'),
    DATABASE_URL: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().url('DATABASE_URL must be a valid URL'),
    NODE_ENV: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].enum([
        'development',
        'production',
        'test'
    ]).default('development'),
    USE_MOCK_DB: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().default('false').transform((v)=>v === 'true'),
    POSTGRES_PASSWORD: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().min(1, 'POSTGRES_PASSWORD is required').optional(),
    PGADMIN_DEFAULT_PASSWORD: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().min(1, 'PGADMIN_DEFAULT_PASSWORD is required').optional(),
    NEXT_PUBLIC_APP_URL: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().url('NEXT_PUBLIC_APP_URL must be a valid URL').optional()
});
let validatedEnv = null;
/**
 * Check if we're running on the server side
 */ function isServer() {
    return ("TURBOPACK compile-time value", "object") === 'undefined';
}
function validateEnv(env) {
    if (validatedEnv) return validatedEnv;
    // Only validate on server side
    if (!isServer()) {
        // Return dummy values for client-side (these won't be used)
        return {
            JWT_SECRET: 'client-side-placeholder',
            DATABASE_URL: 'postgresql://placeholder',
            NODE_ENV: 'development',
            USE_MOCK_DB: false
        };
    }
    //TURBOPACK unreachable
    ;
    const result = undefined;
}
function getEnv() {
    if (!validatedEnv) {
        return validateEnv(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env);
    }
    return validatedEnv;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/auth.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "canAccessRoute",
    ()=>canAccessRoute,
    "canAccessWithScope",
    ()=>canAccessWithScope,
    "canApproveLeaveFor",
    ()=>canApproveLeaveFor,
    "generateToken",
    ()=>generateToken,
    "getNextApprover",
    ()=>getNextApprover,
    "getTokenFromHeader",
    ()=>getTokenFromHeader,
    "hasPermission",
    ()=>hasPermission,
    "hashPassword",
    ()=>hashPassword,
    "isHigherInHierarchy",
    ()=>isHigherInHierarchy,
    "verifyPassword",
    ()=>verifyPassword,
    "verifyToken",
    ()=>verifyToken
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jsonwebtoken$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/jsonwebtoken/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bcryptjs$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/bcryptjs/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/types.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$env$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/env.ts [app-client] (ecmascript)");
;
;
;
;
const env = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$env$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getEnv"])();
const JWT_SECRET = env.JWT_SECRET;
const JWT_EXPIRES_IN = '7d';
async function hashPassword(password) {
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bcryptjs$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].hash(password, 12);
}
async function verifyPassword(password, hashedPassword) {
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bcryptjs$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].compare(password, hashedPassword);
}
function generateToken(user) {
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jsonwebtoken$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].sign({
        id: user.id,
        employeeId: user.employeeId,
        email: user.email,
        name: user.name,
        role: user.role,
        departmentId: user.departmentId,
        subUnitId: user.subUnitId,
        permissions: user.permissions
    }, JWT_SECRET, {
        expiresIn: JWT_EXPIRES_IN
    });
}
function verifyToken(token) {
    try {
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jsonwebtoken$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].verify(token, JWT_SECRET);
    } catch  {
        return null;
    }
}
function getTokenFromHeader(authHeader) {
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
        return null;
    }
    return authHeader.substring(7);
}
function hasPermission(roleOrUser, permission, userPermissions) {
    let role;
    let permissions = userPermissions;
    // ถ้าส่ง AuthUser object มา
    if (typeof roleOrUser === 'object' && roleOrUser !== null && 'role' in roleOrUser) {
        role = roleOrUser.role;
        permissions = roleOrUser.permissions || userPermissions;
    } else {
        role = roleOrUser;
    }
    // ถ้ามี custom permissions ให้ใช้ก่อน
    if (permissions && permissions[permission] !== undefined) {
        return permissions[permission] ?? false;
    }
    // ใช้ default permissions ตาม role
    return __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultRolePermissions"][role]?.[permission] ?? false;
}
function canAccessWithScope(userRole, userScope, resourceDepartmentId, resourceSubUnitId, resourceUserId, currentUserId) {
    const scope = userScope || __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultRoleScope"][userRole];
    switch(scope.type){
        case 'ALL':
            return true;
        case 'DEPARTMENT':
            if (scope.departmentIds && scope.departmentIds.length > 0) {
                return resourceDepartmentId ? scope.departmentIds.includes(resourceDepartmentId) : false;
            }
            return true; // ถ้าไม่ได้กำหนด departmentIds = ทุก department ที่ตัวเองอยู่
        case 'SUBUNIT':
            if (scope.subUnitIds && scope.subUnitIds.length > 0) {
                return resourceSubUnitId ? scope.subUnitIds.includes(resourceSubUnitId) : false;
            }
            return true;
        case 'TEAM':
            if (scope.userIds && scope.userIds.length > 0) {
                return resourceUserId ? scope.userIds.includes(resourceUserId) : false;
            }
            return false;
        case 'SELF':
            return resourceUserId === currentUserId;
        default:
            return false;
    }
}
function canApproveLeaveFor(approverRole, approverId, targetUserRole, targetUserSupervisorId) {
    // 1. ตรวจสอบว่าเป็น supervisor โดยตรงหรือไม่
    if (targetUserSupervisorId === approverId) {
        return true;
    }
    // 2. ตรวจสอบจาก LeaveApprovalChain
    const allowedApprovers = __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LeaveApprovalChain"][targetUserRole];
    if (allowedApprovers && allowedApprovers.includes(approverRole)) {
        return true;
    }
    // 3. ADMIN สามารถอนุมัติได้ทุกคน
    if (approverRole === __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Role"].ADMIN) {
        return true;
    }
    return false;
}
function getNextApprover(userRole) {
    return __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LeaveApprovalChain"][userRole] || [];
}
function isHigherInHierarchy(role1, role2) {
    return __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RoleHierarchy"][role1] > __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RoleHierarchy"][role2];
}
function canAccessRoute(role, route) {
    const routePermissions = {
        '/admin': [
            __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Role"].ADMIN
        ],
        '/dashboard/admin': [
            __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Role"].ADMIN
        ],
        '/dashboard/finance': [
            __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Role"].ADMIN,
            __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Role"].FINANCE_LEADER,
            __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Role"].FINANCE
        ],
        '/dashboard/sales': [
            __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Role"].ADMIN,
            __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Role"].SALES_LEADER,
            __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Role"].SALES
        ],
        '/dashboard/head-tech': [
            __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Role"].ADMIN,
            __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Role"].HEAD_TECH
        ],
        '/dashboard/leader': [
            __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Role"].ADMIN,
            __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Role"].LEADER
        ],
        '/dashboard/tech': [
            __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Role"].ADMIN,
            __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Role"].TECH
        ],
        '/tasks': [
            __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Role"].ADMIN,
            __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Role"].CUSTOMER_SERVICE,
            __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Role"].FINANCE_LEADER,
            __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Role"].FINANCE,
            __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Role"].SALES_LEADER,
            __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Role"].SALES,
            __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Role"].HEAD_TECH,
            __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Role"].LEADER,
            __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Role"].TECH
        ],
        '/leaves': [
            __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Role"].ADMIN,
            __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Role"].CUSTOMER_SERVICE,
            __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Role"].FINANCE_LEADER,
            __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Role"].FINANCE,
            __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Role"].SALES_LEADER,
            __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Role"].SALES,
            __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Role"].HEAD_TECH,
            __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Role"].LEADER,
            __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Role"].TECH
        ],
        '/cars': [
            __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Role"].ADMIN,
            __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Role"].HEAD_TECH,
            __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Role"].LEADER
        ],
        '/users': [
            __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Role"].ADMIN,
            __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Role"].FINANCE_LEADER,
            __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Role"].SALES_LEADER,
            __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Role"].HEAD_TECH
        ],
        '/reports': [
            __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Role"].ADMIN,
            __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Role"].CUSTOMER_SERVICE,
            __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Role"].FINANCE_LEADER,
            __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Role"].FINANCE,
            __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Role"].SALES_LEADER,
            __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Role"].HEAD_TECH,
            __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Role"].LEADER
        ]
    };
    const allowedRoles = routePermissions[route];
    if (!allowedRoles) return true; // If not specified, allow access
    return allowedRoles.includes(role);
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/contexts/AuthContext.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AuthProvider",
    ()=>AuthProvider,
    "useAuth",
    ()=>useAuth,
    "usePermissions",
    ()=>usePermissions,
    "useRoleAccess",
    ()=>useRoleAccess
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/types.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$auth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/auth.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature(), _s2 = __turbopack_context__.k.signature(), _s3 = __turbopack_context__.k.signature();
'use client';
;
;
;
const AuthContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(undefined);
function AuthProvider({ children }) {
    _s();
    const [user, setUser] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [token, setToken] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [isLoading, setIsLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const logout = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "AuthProvider.useCallback[logout]": ()=>{
            setUser(null);
            setToken(null);
            localStorage.removeItem('token');
            localStorage.removeItem('user');
        }
    }["AuthProvider.useCallback[logout]"], []);
    const verifyToken = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "AuthProvider.useCallback[verifyToken]": async (authToken)=>{
            try {
                const response = await fetch('/api/auth/me', {
                    headers: {
                        Authorization: `Bearer ${authToken}`
                    }
                });
                if (response.ok) {
                    const data = await response.json();
                    if (data.success) {
                        setUser(data.data);
                    } else {
                        logout();
                    }
                } else {
                    logout();
                }
            } catch (error) {
                console.error('Token verification failed:', error);
                logout();
            } finally{
                setIsLoading(false);
            }
        }
    }["AuthProvider.useCallback[verifyToken]"], [
        logout
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AuthProvider.useEffect": ()=>{
            // Check for stored token on mount
            const storedToken = localStorage.getItem('token');
            const storedUser = localStorage.getItem('user');
            if (storedToken && storedUser) {
                setToken(storedToken);
                setUser(JSON.parse(storedUser));
                // Verify token is still valid
                verifyToken(storedToken);
            } else {
                setIsLoading(false);
            }
        }
    }["AuthProvider.useEffect"], [
        verifyToken
    ]);
    const login = async (email, password)=>{
        const response = await fetch('/api/auth/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                email,
                password
            })
        });
        const data = await response.json();
        if (!response.ok || !data.success) {
            throw new Error(data.error || 'เข้าสู่ระบบไม่สำเร็จ');
        }
        const { user: userData, token: authToken } = data.data;
        setUser(userData);
        setToken(authToken);
        localStorage.setItem('token', authToken);
        localStorage.setItem('user', JSON.stringify(userData));
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(AuthContext.Provider, {
        value: {
            user,
            token,
            isLoading,
            login,
            logout,
            isAuthenticated: !!user
        },
        children: children
    }, void 0, false, {
        fileName: "[project]/contexts/AuthContext.tsx",
        lineNumber: 95,
        columnNumber: 5
    }, this);
}
_s(AuthProvider, "RRM8pBsM2JnarqUXzYyzwgbC/js=");
_c = AuthProvider;
function useAuth() {
    _s1();
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(AuthContext);
    if (context === undefined) {
        throw new Error('useAuth must be used within an AuthProvider');
    }
    return context;
}
_s1(useAuth, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
function useRoleAccess() {
    _s2();
    const { user } = useAuth();
    const hasRole = (roles)=>{
        if (!user) return false;
        const allowedRoles = Array.isArray(roles) ? roles : [
            roles
        ];
        return allowedRoles.includes(user.role);
    };
    // Role checks - ครบทุก role ในโครงสร้างใหม่
    const isAdmin = user?.role === __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Role"].ADMIN;
    const isCustomerService = user?.role === __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Role"].CUSTOMER_SERVICE;
    const isFinanceLeader = user?.role === __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Role"].FINANCE_LEADER;
    const isFinance = user?.role === __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Role"].FINANCE;
    const isSalesLeader = user?.role === __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Role"].SALES_LEADER;
    const isSales = user?.role === __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Role"].SALES;
    const isHeadTech = user?.role === __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Role"].HEAD_TECH;
    const isLeader = user?.role === __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Role"].LEADER;
    const isTech = user?.role === __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Role"].TECH;
    // Group checks
    const isAnyFinance = isFinanceLeader || isFinance;
    const isAnySales = isSalesLeader || isSales;
    const isAnyTech = isHeadTech || isLeader || isTech;
    const isAnyLeader = isFinanceLeader || isSalesLeader || isHeadTech || isLeader;
    const canManageTeam = isAdmin || isFinanceLeader || isSalesLeader || isHeadTech || isLeader;
    return {
        hasRole,
        isAdmin,
        isCustomerService,
        isFinanceLeader,
        isFinance,
        isSalesLeader,
        isSales,
        isHeadTech,
        isLeader,
        isTech,
        // Group checks
        isAnyFinance,
        isAnySales,
        isAnyTech,
        isAnyLeader,
        canManageTeam
    };
}
_s2(useRoleAccess, "9ep4vdl3mBfipxjmc+tQCDhw6Ik=", false, function() {
    return [
        useAuth
    ];
});
function usePermissions() {
    _s3();
    const { user } = useAuth();
    // ตรวจสอบ permission
    const hasPermission = (permission)=>{
        if (!user) return false;
        // ตรวจสอบ custom permissions ก่อน
        const extendedUser = user;
        if (extendedUser.permissions && extendedUser.permissions[permission] !== undefined) {
            return extendedUser.permissions[permission] ?? false;
        }
        // ใช้ default permissions ตาม role
        return __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultRolePermissions"][user.role]?.[permission] ?? false;
    };
    // ตรวจสอบว่าสามารถเข้าถึง resource ตาม scope ได้หรือไม่
    const canAccessResource = (resourceDepartmentId, resourceSubUnitId, resourceUserId)=>{
        if (!user) return false;
        const extendedUser = user;
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$auth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["canAccessWithScope"])(user.role, extendedUser.permissionScope || __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultRoleScope"][user.role], resourceDepartmentId, resourceSubUnitId, resourceUserId, user.id);
    };
    // ตรวจสอบว่าสามารถอนุมัติใบลาของ user นั้นได้หรือไม่
    const canApproveLeave = (targetUserRole, targetUserSupervisorId)=>{
        if (!user) return false;
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$auth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["canApproveLeaveFor"])(user.role, user.id, targetUserRole, targetUserSupervisorId);
    };
    return {
        hasPermission,
        canAccessResource,
        canApproveLeave,
        // Quick permission checks
        canViewTasks: hasPermission('canViewTasks'),
        canCreateTasks: hasPermission('canCreateTasks'),
        canEditTaskDetails: hasPermission('canEditTaskDetails'),
        canDeleteTasks: hasPermission('canDeleteTasks'),
        canAssignTasks: hasPermission('canAssignTasks'),
        canManageTasks: hasPermission('canManageTasks'),
        canViewAllCalendars: hasPermission('canViewAllCalendars'),
        canViewTeamCalendar: hasPermission('canViewTeamCalendar'),
        canBookVehicles: hasPermission('canBookVehicles'),
        canManageFleet: hasPermission('canManageFleet'),
        canApproveLeaveRequests: hasPermission('canApproveLeave'),
        canViewLeaveRequests: hasPermission('canViewLeaveRequests'),
        canManageUsers: hasPermission('canManageUsers'),
        canViewAllUsers: hasPermission('canViewAllUsers'),
        canManageDailyTechnician: hasPermission('canManageDailyTechnician'),
        canViewReports: hasPermission('canViewReports'),
        canExportData: hasPermission('canExportData')
    };
}
_s3(usePermissions, "9ep4vdl3mBfipxjmc+tQCDhw6Ik=", false, function() {
    return [
        useAuth
    ];
});
var _c;
__turbopack_context__.k.register(_c, "AuthProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/contexts/OfflineContext.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "OfflineProvider",
    ()=>OfflineProvider,
    "useOffline",
    ()=>useOffline
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$uuid$2f$dist$2f$v4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__v4$3e$__ = __turbopack_context__.i("[project]/node_modules/uuid/dist/v4.js [app-client] (ecmascript) <export default as v4>");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
'use client';
;
;
const OfflineContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(undefined);
const STORAGE_KEY = 'offline_actions';
const DEVICE_ID_KEY = 'device_id';
// Helper to get or create device ID (runs synchronously for lazy initialization)
function getOrCreateDeviceId() {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    let id = localStorage.getItem(DEVICE_ID_KEY);
    if (!id) {
        id = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$uuid$2f$dist$2f$v4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__v4$3e$__["v4"])();
        localStorage.setItem(DEVICE_ID_KEY, id);
    }
    return id;
}
// Helper to load pending actions from localStorage
function loadPendingActions() {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    const stored = localStorage.getItem(STORAGE_KEY);
    if (!stored) return [];
    try {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed)) {
            return parsed.filter((action)=>action && typeof action.id === 'string' && typeof action.timestamp === 'number');
        }
    } catch (e) {
        console.error('Failed to parse stored offline actions:', e);
        localStorage.removeItem(STORAGE_KEY);
    }
    return [];
}
function OfflineProvider({ children }) {
    _s();
    // Use lazy initialization to avoid useEffect for initial state
    const [isOnline, setIsOnline] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        "OfflineProvider.useState": ()=>typeof navigator !== 'undefined' ? navigator.onLine : true
    }["OfflineProvider.useState"]);
    const [pendingActions, setPendingActions] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(loadPendingActions);
    const [deviceId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(getOrCreateDeviceId);
    // Use ref to store sync function for use in event handler
    const syncRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    // Remove specific action from pending list
    const removeAction = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "OfflineProvider.useCallback[removeAction]": (actionId)=>{
            setPendingActions({
                "OfflineProvider.useCallback[removeAction]": (prev)=>prev.filter({
                        "OfflineProvider.useCallback[removeAction]": (action)=>action.id !== actionId
                    }["OfflineProvider.useCallback[removeAction]"])
            }["OfflineProvider.useCallback[removeAction]"]);
        }
    }["OfflineProvider.useCallback[removeAction]"], []);
    // Remove only successfully synced actions (by IDs)
    const removeSyncedActions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "OfflineProvider.useCallback[removeSyncedActions]": (syncedIds)=>{
            if (syncedIds.length === 0) return;
            setPendingActions({
                "OfflineProvider.useCallback[removeSyncedActions]": (prev)=>prev.filter({
                        "OfflineProvider.useCallback[removeSyncedActions]": (action)=>!syncedIds.includes(action.id)
                    }["OfflineProvider.useCallback[removeSyncedActions]"])
            }["OfflineProvider.useCallback[removeSyncedActions]"]);
        }
    }["OfflineProvider.useCallback[removeSyncedActions]"], []);
    const syncPendingActions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "OfflineProvider.useCallback[syncPendingActions]": async ()=>{
            if (!navigator.onLine || pendingActions.length === 0) {
                return {
                    success: true,
                    synced: 0,
                    failed: 0,
                    syncedIds: [],
                    failedIds: []
                };
            }
            const token = localStorage.getItem('token');
            if (!token) {
                return {
                    success: false,
                    synced: 0,
                    failed: pendingActions.length,
                    errors: [
                        'Not authenticated'
                    ],
                    syncedIds: [],
                    failedIds: pendingActions.map({
                        "OfflineProvider.useCallback[syncPendingActions]": (a)=>a.id
                    }["OfflineProvider.useCallback[syncPendingActions]"])
                };
            }
            try {
                const response = await fetch('/api/sync', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        Authorization: `Bearer ${token}`
                    },
                    body: JSON.stringify({
                        actions: pendingActions,
                        deviceId
                    })
                });
                const data = await response.json();
                if (data.success && data.data) {
                    const result = data.data;
                    // ลบเฉพาะ action ที่ sync สำเร็จจริงๆ เท่านั้น
                    if (result.syncedIds && result.syncedIds.length > 0) {
                        removeSyncedActions(result.syncedIds);
                    } else if (result.synced === pendingActions.length && result.failed === 0) {
                        // Fallback: ถ้า API ไม่ส่ง syncedIds แต่ sync สำเร็จทั้งหมด
                        setPendingActions([]);
                    }
                    return result;
                } else {
                    return {
                        success: false,
                        synced: 0,
                        failed: pendingActions.length,
                        errors: [
                            data.error || 'Sync failed'
                        ],
                        syncedIds: [],
                        failedIds: pendingActions.map({
                            "OfflineProvider.useCallback[syncPendingActions]": (a)=>a.id
                        }["OfflineProvider.useCallback[syncPendingActions]"])
                    };
                }
            } catch (error) {
                return {
                    success: false,
                    synced: 0,
                    failed: pendingActions.length,
                    errors: [
                        error instanceof Error ? error.message : 'Network error'
                    ],
                    syncedIds: [],
                    failedIds: pendingActions.map({
                        "OfflineProvider.useCallback[syncPendingActions]": (a)=>a.id
                    }["OfflineProvider.useCallback[syncPendingActions]"])
                };
            }
        }
    }["OfflineProvider.useCallback[syncPendingActions]"], [
        pendingActions,
        deviceId,
        removeSyncedActions
    ]);
    // Retry only failed actions
    const retryFailedActions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "OfflineProvider.useCallback[retryFailedActions]": async ()=>{
            // Simply call syncPendingActions since pendingActions now only contains failed ones
            return syncPendingActions();
        }
    }["OfflineProvider.useCallback[retryFailedActions]"], [
        syncPendingActions
    ]);
    // Keep ref updated in effect
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "OfflineProvider.useEffect": ()=>{
            syncRef.current = syncPendingActions;
        }
    }["OfflineProvider.useEffect"], [
        syncPendingActions
    ]);
    // Set up online/offline listeners
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "OfflineProvider.useEffect": ()=>{
            const handleOnline = {
                "OfflineProvider.useEffect.handleOnline": ()=>{
                    setIsOnline(true);
                    // Auto-sync when coming back online
                    syncRef.current?.();
                }
            }["OfflineProvider.useEffect.handleOnline"];
            const handleOffline = {
                "OfflineProvider.useEffect.handleOffline": ()=>{
                    setIsOnline(false);
                }
            }["OfflineProvider.useEffect.handleOffline"];
            window.addEventListener('online', handleOnline);
            window.addEventListener('offline', handleOffline);
            return ({
                "OfflineProvider.useEffect": ()=>{
                    window.removeEventListener('online', handleOnline);
                    window.removeEventListener('offline', handleOffline);
                }
            })["OfflineProvider.useEffect"];
        }
    }["OfflineProvider.useEffect"], []);
    // Save pending actions to localStorage whenever they change
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "OfflineProvider.useEffect": ()=>{
            localStorage.setItem(STORAGE_KEY, JSON.stringify(pendingActions));
        }
    }["OfflineProvider.useEffect"], [
        pendingActions
    ]);
    const addOfflineAction = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "OfflineProvider.useCallback[addOfflineAction]": (action)=>{
            const newAction = {
                ...action,
                id: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$uuid$2f$dist$2f$v4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__v4$3e$__["v4"])(),
                timestamp: Date.now()
            };
            setPendingActions({
                "OfflineProvider.useCallback[addOfflineAction]": (prev)=>[
                        ...prev,
                        newAction
                    ]
            }["OfflineProvider.useCallback[addOfflineAction]"]);
        }
    }["OfflineProvider.useCallback[addOfflineAction]"], []);
    const clearPendingActions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "OfflineProvider.useCallback[clearPendingActions]": ()=>{
            setPendingActions([]);
            localStorage.removeItem(STORAGE_KEY);
        }
    }["OfflineProvider.useCallback[clearPendingActions]"], []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(OfflineContext.Provider, {
        value: {
            isOnline,
            pendingActions,
            addOfflineAction,
            syncPendingActions,
            clearPendingActions,
            removeAction,
            retryFailedActions,
            deviceId
        },
        children: children
    }, void 0, false, {
        fileName: "[project]/contexts/OfflineContext.tsx",
        lineNumber: 202,
        columnNumber: 5
    }, this);
}
_s(OfflineProvider, "roWCeaKfS6GMHaivzVOcbdRp/EQ=");
_c = OfflineProvider;
function useOffline() {
    _s1();
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(OfflineContext);
    if (context === undefined) {
        throw new Error('useOffline must be used within an OfflineProvider');
    }
    return context;
}
_s1(useOffline, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
var _c;
__turbopack_context__.k.register(_c, "OfflineProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ui/Toaster.tsx [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Toaster",
    ()=>Toaster
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/sonner/dist/index.mjs [app-client] (ecmascript)");
'use client';
;
;
function Toaster() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Toaster"], {
        position: "top-right",
        expand: true,
        richColors: true,
        closeButton: true,
        toastOptions: {
            style: {
                background: 'rgba(255, 255, 255, 0.9)',
                backdropFilter: 'blur(10px)',
                border: '1px solid rgba(255, 255, 255, 0.2)',
                boxShadow: '0 8px 32px rgba(0, 0, 0, 0.1)'
            },
            classNames: {
                toast: 'rounded-xl',
                title: 'font-semibold text-gray-900',
                description: 'text-gray-600',
                success: 'border-l-4 border-l-green-500',
                error: 'border-l-4 border-l-red-500',
                warning: 'border-l-4 border-l-yellow-500',
                info: 'border-l-4 border-l-blue-500'
            }
        }
    }, void 0, false, {
        fileName: "[project]/components/ui/Toaster.tsx",
        lineNumber: 7,
        columnNumber: 5
    }, this);
}
_c = Toaster;
;
var _c;
__turbopack_context__.k.register(_c, "Toaster");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/contexts/Providers.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Providers",
    ()=>Providers
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$queryClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/query-core/build/modern/queryClient.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-query/build/modern/QueryClientProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$AuthContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/contexts/AuthContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$OfflineContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/contexts/OfflineContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$Toaster$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/components/ui/Toaster.tsx [app-client] (ecmascript) <locals>");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
function Providers({ children }) {
    _s();
    const [queryClient] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        "Providers.useState": ()=>new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$queryClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryClient"]({
                defaultOptions: {
                    queries: {
                        staleTime: 60 * 1000,
                        gcTime: 5 * 60 * 1000,
                        retry: 3,
                        refetchOnWindowFocus: false
                    }
                }
            })
    }["Providers.useState"]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryClientProvider"], {
        client: queryClient,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$AuthContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AuthProvider"], {
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$OfflineContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["OfflineProvider"], {
                children: [
                    children,
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$Toaster$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Toaster"], {}, void 0, false, {
                        fileName: "[project]/contexts/Providers.tsx",
                        lineNumber: 29,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/contexts/Providers.tsx",
                lineNumber: 27,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/contexts/Providers.tsx",
            lineNumber: 26,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/contexts/Providers.tsx",
        lineNumber: 25,
        columnNumber: 5
    }, this);
}
_s(Providers, "jm/5KbLuyP86FdAbrW+YNWYYqZI=");
_c = Providers;
var _c;
__turbopack_context__.k.register(_c, "Providers");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=_fea5af41._.js.map
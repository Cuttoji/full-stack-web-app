(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_fa4b89fc._.js",
  "static/chunks/node_modules_motion-dom_dist_es_da948acf._.js",
  "static/chunks/node_modules_framer-motion_dist_es_247c3ff9._.js",
  "static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_56b6fd65._.js",
  "static/chunks/node_modules_date-fns_c9f22fec._.js",
  "static/chunks/node_modules_ab918e6e._.js"
],
    source: "dynamic"
});

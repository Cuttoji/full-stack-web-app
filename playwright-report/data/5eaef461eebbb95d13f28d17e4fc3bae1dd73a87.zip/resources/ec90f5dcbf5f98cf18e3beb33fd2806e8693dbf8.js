(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__28bc9c2a._.css",
  "static/chunks/node_modules_next_dist_compiled_crypto-browserify_index_44cf344e.js",
  "static/chunks/node_modules_next_dist_compiled_13f06b32._.js",
  "static/chunks/node_modules_zod_v4_17b17601._.js",
  "static/chunks/node_modules_a10d0ac1._.js",
  "static/chunks/_fea5af41._.js"
],
    source: "dynamic"
});
